import torch
from torch import randint as origin_randint
from torch import randn as origin_randn
from torch import rand as origin_rand

import ascend_rand_adapter._C
from ascend_rand_adapter._C import set_device_info

all=["set_device"]

def set_device(device):
    assert(isinstance(device, str), "device must be str")
    if device.upper() == "A100":
        set_device_info(108, 2048)
    elif device.upper() == "A30":
        set_device_info(56, 2048)
    elif device.upper() == "L20":
        set_device_info(92, 1536)
    else:
        raise RuntimeError("unknown device, device should be a100/a30/l20")

def _is_npu_or_cuda_device(device):
    # torch 2.3 is different from 2.1, so is_npu_default has 2 impl
    if device is None:
        if hasattr(torch, "get_default_device"):
            is_npu_default = torch.get_default_device().type in ("npu", "cuda")
        else:
            is_npu_default = torch._GLOBAL_DEVICE_CONTEXT is not None and torch._GLOBAL_DEVICE_CONTEXT.device.type in ("npu", "cuda")
        if is_npu_default:
            return True
    elif torch.device(device).type in ("npu", "cuda"):
        return True
    return False

def _randint(*args, **kwargs):
    device = kwargs.get("device", None)
    generator = kwargs.get("generator", None)
    if _is_npu_or_cuda_device(device):
        device = "npu" if device is None else device
        if len(args) == 3:
            return ascend_rand_adapter._C.randint(*args, generator).to(device)
        else:
            size = kwargs["size"] if "size" in kwargs else args[-1]
            high = kwargs.get("high", None)
            low = kwargs.get("low", None)
            if high is None:
                for arg in args:
                    if isinstance(arg, int):
                        low = high
                        high = arg
                if low is None:
                    low = 0
            elif low is None:
                low = 0
                for arg in args:
                    if isinstance(arg, int):
                        low = arg
            return ascend_rand_adapter._C.randint(low, high, size, generator).to(device)
    return origin_randint(*args, **kwargs)


def _randn(*args, **kwargs):
    device = kwargs.get("device", None)
    generator = kwargs.get("generator", None)
    size = kwargs["size"] if "size" in kwargs else args[0]
    if _is_npu_or_cuda_device(device):
        device = "npu" if device is None else device
        return ascend_rand_adapter._C.randn(size, generator).to(device)
    return origin_randn(*args, **kwargs)

def _rand(*args, **kwargs):
    device = kwargs.get("device", None)
    generator = kwargs.get("generator", None)
    size = kwargs["size"] if "size" in kwargs else args[0]
    if _is_npu_or_cuda_device(device):
        device = "npu" if device is None else device
        return ascend_rand_adapter._C.rand(size, generator).to(device)
    return origin_rand(*args, **kwargs)


def _exponential_(self: torch.Tensor, lambd: float = 1.0, generator = None) -> torch.Tensor:
    # 参数检查
    if lambd <= 0.0:
        raise ValueError(f"exponential_ expects lambd > 0.0, but found lambd={lambd}")
    
    # 处理无穷大情况
    if torch.isinf(torch.tensor(lambd)):
        self.zero_()
        return self
    # 生成均匀分布随机数 [0, 1)

    self_ = ascend_rand_adapter._C.rand(self.shape, generator).to(self.device)

    self_.masked_fill_(self_==0, 1.0)

    eps = torch.finfo(self_.dtype).eps / 2
    mask = self_ >= 1 - eps
    self_.log_()
    self_.masked_fill_(mask, -eps)
    self_.neg_()
    self_.div_(lambd)

    self.copy_(self_)
    return self


# torch.randint = _randint
# torch.randn = _randn
# torch.rand = _rand
# torch.manual_seed = ascend_rand_adapter._C.manual_seed

# torch.Tensor.exponential_ = _exponential_
